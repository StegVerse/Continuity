# NOTICE

This repository is governed by the **StegVerse Guardian License (v1.0, 2025)**.

Purpose: To maintain the continuity, integrity, and mission of the StegVerse ecosystem 
in the event of maintainer unavailability.

See LICENSE.md for full license terms and usage restrictions.
