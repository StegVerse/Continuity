# StegVerse Continuity (Guardian Mode)
This repo keeps StegVerse alive if the maintainer is unavailable.
Refer to LICENSE.md for Guardian License terms.
